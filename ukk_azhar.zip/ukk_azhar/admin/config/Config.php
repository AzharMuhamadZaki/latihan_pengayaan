<?php

define('baseurl','http://localhost/ukk_azhar/public');